<html>
<head>

<title>Recebendo dados da página</title>
<meta charset="UTF-8"/>
<meta name="description" content="Recebendo dados da pagina hrml"/>
<meta name="keywords" content="$_POST , $_GET"/>
</head>
<body>

<?PHP

$Nome = $_POST["Nome"];
$Email = $_POST["Email"];
$Telefone = $_POST["Telefone"];
$Mensagem = $_POST["Mensagem"];
$comando = "insert into contato (Nome , Email , Telefone , Mensagem ) values ('$Nome' , '$Email' , '$Telefone' , '$Mensagem ')";
echo($comando);
$cone = mysqli_connect("localhost","root","","GTech") or die ("Erro ao conectar ao bd");
$executar = mysqli_query($cone,$comando) or die ("Erro ao cadastrar");

if ($executar){
	echo "<script>alert('Cadastrado com sucesso!');Window.location.href= 'index.html'</script>";
	
}

?>
</body>
</html>